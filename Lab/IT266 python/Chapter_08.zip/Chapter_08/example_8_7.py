# Program to Iterate Over Items in Sets Using for Loop

warships = {"u.s.s._arizona", "hms_beagle", "ins_airavat", "ins_hetz"}
def main():
    for each_ship in warships:
        print(f"{each_ship} is a Warship")

if __name__ == "__main__":
    main()

# Output
# hms_beagle is a Warship
# u.s.s._arizona is a Warship
# ins_airavat is a Warship
# ins_hetz is a Warship
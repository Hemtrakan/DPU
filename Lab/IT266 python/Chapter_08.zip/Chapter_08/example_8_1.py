# Program to Iterate Over Items in Tuples Using for Loop

ocean_animals = ("electric_eel", "jelly_fish", "shrimp", "turtles", "blue_whale")
def main():
    for each_animal in ocean_animals:
        print(f"{each_animal} is an ocean animal")

if __name__ == "__main__":
    main()

# Output
# electric_eel is an ocean animal
# jelly_fish is an ocean animal
# shrimp is an ocean animal
# turtle is an ocean animal
# blue_whale is an ocean animal
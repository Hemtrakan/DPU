def common_characters(string_1, string_2):
    for letter in string_1:
        if letter in string_2:
            print(f"Character '{letter}' is found in both the strings")

def main():
    common_characters('rose', 'goose')

if __name__ == "__main__":
    main()

# Output example
#Character 'o' is found in both the strings
#Character 's' is found in both the strings
#Character 'e' is found in both the strings

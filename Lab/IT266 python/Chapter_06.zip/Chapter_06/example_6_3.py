# Program to Display the Index Values of Items in List

silicon_valley = ["google", "amd", "yahoo", "cisco", "oracle"]
for index_value in range(len(silicon_valley)):
    print(f"The index value of '{silicon_valley[index_value]}' is {index_value}")

# Output
# The index value of 'google' is 0
# The index value of 'amd' is 1
# The index value of 'yahoo' is 2
# The index value of 'cisco' is 3
# The index value of 'oracle' is 4

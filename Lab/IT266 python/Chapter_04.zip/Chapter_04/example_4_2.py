def area_trapezium(a, b, h):
    area = 0.5 * (a + b) * h
    print(f"Area of a Trapezium is {area}")

def main():
    area_trapezium(10, 15, 20)

if __name__ == "__main__":
    main()

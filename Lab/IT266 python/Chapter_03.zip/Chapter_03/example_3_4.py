number_1 = int(input("Enter the first number"))
number_2 = int(input("Enter the second number"))
if number_1 > number_2:
    print(f"{number_1} is greater than {number_2}")
else:
    print(f"{number_2} is greater than {number_1}")

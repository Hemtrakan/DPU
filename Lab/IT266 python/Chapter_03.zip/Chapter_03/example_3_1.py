number = int(input("Enter a number "))
if number >= 0:
    print(f"The number entered by the user is a positive number")

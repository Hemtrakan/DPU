for each_character in "Blue":
    print(f"Iterate through character {each_character} in the string 'Blue'")

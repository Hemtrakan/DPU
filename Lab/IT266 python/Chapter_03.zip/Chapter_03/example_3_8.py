i = 0
while i < 10:
    print(f"Current value of i is {i}")
    i = i + 1

weight = int(input("How many pounds does your suitcase weigh?"))
if weight > 50:
    print(f"There is a $25 surcharge for heavy luggage")
    print(f"Thank you")

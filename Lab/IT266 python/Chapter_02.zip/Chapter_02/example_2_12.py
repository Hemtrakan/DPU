int_to_hex = hex(255)
print(f"After Integer to Hex Casting the result is {int_to_hex}")

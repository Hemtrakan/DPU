country = input("Which country do you live in?")
print(f"I live in {country}")

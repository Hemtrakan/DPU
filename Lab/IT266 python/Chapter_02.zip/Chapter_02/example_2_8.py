int_to_string = str(8)
float_to_string = str(3.5)
print(f"After Integer to String Casting the result is {int_to_string}")
print(f"After Float to String Casting the result is {float_to_string}")

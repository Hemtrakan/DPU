float_to_int = int(3.5)
string_to_int = int("1") #number treated as string
print(f"After Float to Integer Casting the result is {float_to_int}")
print(f"After String to Integer Casting the result is {string_to_int}")

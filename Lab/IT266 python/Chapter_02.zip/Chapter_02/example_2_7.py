int_to_float = float(4)
string_to_float = float("1") #number treated as string
print(f"After Integer to Float Casting the result is {int_to_float}")
print(f"After String to Float Casting the result is {string_to_float}")

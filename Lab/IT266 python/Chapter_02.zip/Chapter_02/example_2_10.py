complex_with_string = complex("1")
complex_with_number = complex(5, 8)
print(f"Result after using string in real part {complex_with_string}")
print(f"Result after using numbers in real and imaginary part {complex_with_number}")

country = input("Which country do you live in? ")
print("I live in {0}".format(country))
